var nombre = 'sacha', edad = 28

function imprimirEdad(n , e){
    console.log(`${n} tiene ${e} años`)
}

imprimirEdad(nombre, edad)

imprimirEdad('Hugo','19')
imprimirEdad('Antonio', '18')
imprimirEdad('Juan')
