var x = 4, y = '4'
//x == y / True //
//para saber si son iguales y con el mismo tipo de variable//
//x === y / False//
// lo ideal es siempre utilizar el triple igual//

var sacha = {
  nombre: ' sacha'
}

var otraPersona = {
  ...sacha
}
