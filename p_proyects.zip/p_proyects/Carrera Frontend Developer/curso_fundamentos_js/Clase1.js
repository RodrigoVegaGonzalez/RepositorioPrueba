var nombre = 'Sacha' , apellido = 'Lifszyc'
var edad = 28
console.log('Hola ' + nombre + ' ' + apellido)
console.log('Tengo ' + edad + ' años')

var peso = 75
