var nombre= 'Victor'

function imprimirMayusculas(n){
  n = n.toUpperCase()
  console.log(n)
}

imprimirMayusculas(nombre)
