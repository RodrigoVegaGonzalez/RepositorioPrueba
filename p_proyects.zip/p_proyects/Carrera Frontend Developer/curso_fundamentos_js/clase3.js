var edad = 27
edad = edad + 1

var peso = 75

//peso = peso - 2//
peso -= 2

var sandwich = 1

peso = peso + sandwich

var jugarFutbol = 3

peso -= jugarFutbol

var precioVino = 200.3

var total = Math.round(precioVino * 100 * 3)/ 100
var totalStr = total.toFixed(2)

var total2= parseFloat(totalStr)

var pizza = 8
var persona = 2
var cantidadPorciconesPersona = pizza/persona
